"""Kalshi Tennis Scanner — read-only market monitoring with tabbed navigation."""
from datetime import datetime, timezone

import pandas as pd
import streamlit as st

from scanner import SERIES, best_opportunity, history, save_snapshots, scan

st.set_page_config(page_title='Kalshi Tennis Scanner', page_icon='🎾', layout='wide')
st.title('Kalshi Tennis Scanner')
st.caption('Choose a clearly labeled tab below to switch between market overview, watchlist, price history, and trade-value analysis. Read-only public quotes; no orders.')

with st.sidebar:
    st.header('Scanner controls')
    tours = st.multiselect('Match-winner series', list(SERIES), default=list(SERIES))
    refresh = st.selectbox('Refresh while dashboard is open', ['Manual', '30 seconds', '60 seconds', '120 seconds'], index=1)
    max_spread = st.slider('Maximum YES spread (¢)', 1, 50, 20)
    min_volume = st.number_input('Minimum 24h contracts traded', min_value=0, value=0, step=25)
    st.info('Quotes do not guarantee fills. No trades are submitted.')
    st.markdown('[Kalshi API documentation](https://docs.kalshi.com/api-reference/market/get-markets)')

if not tours:
    st.warning('Select at least one series in the sidebar.')
    st.stop()

interval = {'Manual': None, '30 seconds': '30s', '60 seconds': '60s', '120 seconds': '120s'}[refresh]

@st.fragment(run_every=interval)
def dashboard():
    if st.button('Refresh market data', type='primary'):
        pass

    started = datetime.now(timezone.utc)
    with st.spinner('Fetching open markets from Kalshi…'):
        rows, errors = scan(tours)
    if errors:
        st.warning('Some requests failed: ' + ' | '.join(errors))
    if not rows:
        st.info('No open tennis contracts returned. This can happen between tournaments or when the API is unavailable. Try another series or refresh later.')
        return

    try:
        save_snapshots(rows)
    except Exception as exc:
        st.warning(f'Unable to store local quote history: {exc}')

    df = pd.DataFrame(rows)
    filtered = df.loc[
        df['spread_c'].notna()
        & (df['spread_c'] <= max_spread)
        & (df['volume_24h'] >= min_volume)
    ].copy()
    st.caption(
        f'Last requested: {started.strftime("%Y-%m-%d %H:%M:%S UTC")} '
        f'· {len(df)} contracts · {len(tours)} series queried'
    )

    overview_tab, watchlist_tab, tracker_tab, analysis_tab = st.tabs([
        '1 · Market Overview', '2 · Market Watchlist', '3 · Price History', '4 · Trade Value Analysis'
    ])

    with overview_tab:
        st.subheader('Tennis market overview')
        c1, c2, c3, c4 = st.columns(4)
        c1.metric('Open contracts', len(df))
        c2.metric('Two-sided quotes', int(df['spread_c'].notna().sum()))
        c3.metric('Median spread', f"{df['spread_c'].median():.1f}¢" if df['spread_c'].notna().any() else 'N/A')
        c4.metric('24h volume (sum)', f"{df['volume_24h'].sum():,.0f}")
        st.caption('Contract counts are not unique match counts. Multiple contracts can refer to the same match.')
        counts = df.groupby('tour', as_index=False).agg(contracts=('ticker', 'count'), volume_24h=('volume_24h', 'sum'))
        st.dataframe(counts.rename(columns={'tour': 'Tour', 'contracts': 'Open contracts', 'volume_24h': '24h contract volume'}), hide_index=True, use_container_width=True)

    with watchlist_tab:
        st.subheader('Filtered market watchlist')
        st.caption('Sidebar controls determine maximum spread and minimum volume. A tight spread does not indicate a mispricing.')
        if filtered.empty:
            st.info('No contracts pass the current spread and volume filters.')
        else:
            filtered = filtered.sort_values(['spread_c', 'volume_24h'], ascending=[True, False])
            show_cols = ['tour', 'title', 'yes_label', 'bid_c', 'ask_c', 'spread_c', 'last_c', 'volume_24h', 'open_interest', 'ticker']
            st.dataframe(filtered[show_cols].rename(columns={
                'tour': 'Tour', 'title': 'Match / contract', 'yes_label': 'YES outcome',
                'bid_c': 'YES bid ¢', 'ask_c': 'YES ask ¢', 'spread_c': 'Spread ¢',
                'last_c': 'Last ¢', 'volume_24h': '24h volume', 'open_interest': 'Open interest',
                'ticker': 'Ticker',
            }), hide_index=True, use_container_width=True)
            st.download_button('Export watchlist CSV', filtered.to_csv(index=False),
                               file_name='kalshi_tennis_watchlist.csv', mime='text/csv')

    # Keep the selection consistent across the separate tracking and analysis tabs.
    market_names = df.drop_duplicates('ticker').set_index('ticker')['title'].to_dict()
    tickers = list(market_names)
    with tracker_tab:
        st.subheader('Historical quote tracker')
        ticker = st.selectbox('Choose a contract', tickers, key='tracking_ticker',
                              format_func=lambda t: f'{market_names.get(t, t)} | {t}')
        row = df.set_index('ticker').loc[ticker].to_dict()
        c1, c2, c3 = st.columns(3)
        c1.metric('YES bid', f"{row['bid_c']}¢" if pd.notna(row['bid_c']) else 'No quote')
        c2.metric('YES ask', f"{row['ask_c']}¢" if pd.notna(row['ask_c']) else 'No quote')
        c3.metric('Spread', f"{row['spread_c']}¢" if pd.notna(row['spread_c']) else 'N/A')
        hist = pd.DataFrame(history(ticker))
        if hist.empty:
            st.info('No local price history for this contract yet.')
        else:
            hist['observed_at'] = pd.to_datetime(hist['observed_at'], utc=True)
            st.line_chart(hist.set_index('observed_at')[['bid_c', 'ask_c']], y_label='YES price (¢)')
            st.caption('Only snapshots collected while the scanner runs are shown; past quotes are not backfilled.')
        st.code(ticker, language=None)

    with analysis_tab:
        st.subheader('Manual fair-value analysis')
        st.caption('Not an automated prediction. Enter your own win probability to explore theoretical YES/NO edge.')
        ticker = st.selectbox('Contract to analyze', tickers, key='analysis_ticker',
                              format_func=lambda t: f'{market_names.get(t, t)} | {t}')
        row = df.set_index('ticker').loc[ticker].to_dict()
        p_pct = st.number_input('Your estimated YES probability (%)', min_value=0.0,
                                max_value=100.0, value=50.0, step=0.5)
        estimated_fee_c = st.number_input('Assumed total trading costs (¢ / contract)',
                                          min_value=0.0, max_value=100.0, value=2.0, step=0.5,
                                          help='Illustrative flat assumption, NOT an official Kalshi fee calculation.')
        opp = best_opportunity(row, p_pct / 100, estimated_fee_c)
        if opp:
            action, edge, price = opp
            a, b = st.columns(2)
            a.metric('Best theoretical edge', f'{edge:+.2f}¢ / contract')
            b.metric('Approximate entry price', f'{price:.2f}¢')
            st.write(f'**Scenario:** {action}')
            if edge > 0:
                st.warning('Hypothetical positive value difference only. Model uncertainty, liquidity, slippage and actual fees may eliminate it.')
            else:
                st.info('No positive theoretical edge under the current assumptions.')
        else:
            st.info('No usable quote for this comparison.')

dashboard()
