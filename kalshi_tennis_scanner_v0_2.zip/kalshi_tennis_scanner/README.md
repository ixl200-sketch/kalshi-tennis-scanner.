# Kalshi Tennis Scanner — v0.2

Read-only Streamlit dashboard that requests **real open tennis match-winner markets** from Kalshi's official public API. It shows quoted YES bid, ask, spread, last trade, 24-hour volume, and open interest, and collects local timestamped quote snapshots in SQLite for trend charts.

## Run

Requires Python 3.10+ and an internet connection.

```bash
cd kalshi_tennis_scanner
python -m pip install -r requirements.txt
streamlit run app.py
```

A browser window opens at `http://localhost:8501`. The dashboard fetches new data each time it loads and can poll every 30, 60, or 120 seconds while the page is open. Press **Refresh market data** to re-query immediately. To run tests:

```bash
python -m unittest discover -s tests -v
```

## Data and caveats

- API: `https://external-api.kalshi.com/trade-api/v2/markets` with `series_ticker` and `status=open`, cursor pagination.
- Targets `KXATPMATCH`, `KXWTAMATCH`, `KXATPCHALLENGERMATCH`, `KXWTACHALLENGERMATCH`, `KXITFMATCH`. Series may be renamed or inactive. You can adjust the `SERIES` dictionary in `scanner.py`.
- Public API access requires **no Kalshi credentials**. App has no order placement code.
- A market record is a contract, not necessarily a unique tennis match. Multiple markets may refer to the same match.
- A quoted ask is an **entry** price, and a quoted bid is an **exit** price. Quoted sizes, delays and slippage impact execution.
- Prices do not establish fair value. The optional model edge display uses a **manually entered probability**, not an actual tennis model; its flat trading-cost assumption is a user-editable illustration and NOT Kalshi's official fee calculation.
- This is a REST polling scanner, not tick-level streaming. Run it continuously to collect history; it cannot retrieve history for time when it was not running.
- If there are no open markets or the host is inaccessible, the dashboard will say so instead of displaying invented opportunities.
- Follow Kalshi's API rate limits, terms, and market-specific rules.

## Next iteration

1. Add verified tennis performance data to train and calibrate independent pre-match fair-value estimates.
2. Add official contract-specific fee models and quote-size-aware execution simulation.
3. Add price history / candlesticks and orderbook depth, with API authorization if required.
4. Implement paper positions, entry/exit criteria, and an audited P&L tracker.
5. Evaluate predictions and hypothetical fills against out-of-sample historical data before considering real trading.

## v0.2: Clearly labeled tabs

The dashboard is now divided into four separate tabs: **1 · Market Overview**, **2 · Market Watchlist**, **3 · Price History**, and **4 · Trade Value Analysis**. Use the sidebar to filter markets, and use **Refresh market data** to request an immediate update. The price tracker and value-analysis tabs have independent contract selectors. All other scanner behavior remains read-only.
