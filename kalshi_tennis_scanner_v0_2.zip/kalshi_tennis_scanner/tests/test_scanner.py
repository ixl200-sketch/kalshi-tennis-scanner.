import unittest
from scanner import normalize, best_opportunity

class ScannerTest(unittest.TestCase):
    def test_quotes_and_spread(self):
        m={'ticker':'T1','yes_bid_dollars':'0.4000','yes_ask_dollars':'0.4500','volume_24h_fp':'123'}
        r=normalize(m,'ATP', '2026-11-23T00:00:00Z')
        self.assertEqual(r['spread_c'],5)
        self.assertEqual(r['ask_c'],45)
    def test_ask_derived_from_no_bid(self):
        r=normalize({'ticker':'T2','no_bid_dollars':'0.6200'},'WTA')
        self.assertEqual(r['ask_c'],38)
    def test_no_fake_quote(self):
        r=normalize({'ticker':'T3'},'ATP')
        self.assertIsNone(r['ask_c'])
    def test_buy_yes_edge(self):
        r=normalize({'ticker':'T4','yes_bid_dollars':'0.45','yes_ask_dollars':'0.5'},'ATP')
        self.assertEqual(best_opportunity(r,0.60,2),('BUY YES',8.0,50.0))
    def test_buy_no_edge(self):
        r=normalize({'ticker':'T5','yes_bid_dollars':'0.75','yes_ask_dollars':'0.8'},'ATP')
        self.assertEqual(best_opportunity(r,0.1,2),('BUY NO',63.0,25.0))

if __name__=='__main__': unittest.main()
